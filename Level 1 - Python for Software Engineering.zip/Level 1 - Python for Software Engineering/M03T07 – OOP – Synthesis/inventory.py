#======== SHOE INVENTORY MANAGEMENT SYSTEM ==========

# This part defines the Shoe class
class Shoe:
    def __init__(self, country, code, product, cost, quantity):
        '''
        Initialize attributes of the Shoe object.
        '''
        self.country = country
        self.code = code
        self.product = product
        self.cost = float(cost)
        self.quantity = int(quantity)

    def get_cost(self):
        '''
        Return the cost of the shoe.
        '''
        return self.cost

    def get_quantity(self):
        '''
        Return the quantity of the shoe.
        '''
        return self.quantity

    def __str__(self):
        '''
        Return a readable string representation of a shoe.
        '''
        return f"{self.country:15} | {self.code:10} | {self.product:20} | R{self.cost:<7.2f} | {self.quantity:>3} pcs"


#============= SHOE LIST =============
# This list will store all Shoe objects
shoe_list = []


#========== FUNCTIONS ==========

def read_shoes_data():
    '''
    Read data from inventory.txt and populate shoe_list with Shoe objects.
    Skips header line and handles errors gracefully.
    '''
    try:
        with open('inventory.txt', 'r') as file:
            lines = file.readlines()
            if len(lines) <= 1:
                print("inventory.txt is empty or missing data.")
                return

            for line in lines[1:]:  # Skip header
                parts = line.strip().split(',')
                if len(parts) == 5:
                    country, code, product, cost, quantity = parts
                    shoe = Shoe(country, code, product, cost, quantity)
                    shoe_list.append(shoe)
    except FileNotFoundError:
        print("File 'inventory.txt' not found.")
    except Exception as e:
        print(f"Error reading file: {e}")


def capture_shoes():
    '''
    Allow user to enter new shoe data, create a Shoe object,
    append it to shoe_list and update the file.
    '''
    print("\nAdd a New Shoe")
    try:
        country = input("Please enter a country: ")
        code = input("Please enter the SKU code: ")
        product = input("Please enter the product name: ")
        cost = float(input("Please enter the cost (e.g. 1500): R"))
        quantity = int(input("Please enter the quantity: "))

        new_shoe = Shoe(country, code, product, cost, quantity)
        shoe_list.append(new_shoe)
        update_inventory_file()
        print("Shoe added successfully!\n")
    except ValueError:
        print("Please enter valid numbers for cost and quantity.\n")


def view_all():
    '''
    Display all shoes in shoe_list in a table format.
    '''
    print("\nAll Shoes in Inventory")
    if not shoe_list:
        print("No shoes found in the inventory.\n")
        return

    print("{:<15} | {:<10} | {:<20} | {:<10} | {:>10}".format("Country", "Code", "Product", "Cost", "Quantity"))
    print("-" * 70)
    for shoe in shoe_list:
        print(shoe)
    print()


def re_stock():
    '''
    Find the shoe with the lowest quantity, ask if user wants to restock,
    and update both shoe_list and inventory.txt.
    '''
    print("\nRestock a Shoe with Low Quantity")
    if not shoe_list:
        print("Inventory is empty.\n")
        return

    lowest = min(shoe_list, key=lambda x: x.get_quantity())
    print(f"🛒 Lowest Stock Shoe:\n{lowest}")

    try:
        choice = input("Do you want to restock this shoe? (yes/no): ").strip().lower()
        if choice == "yes":
            add_qty = int(input("How many units do you want to add? "))
            lowest.quantity += add_qty
            update_inventory_file()
            print("Shoe restocked successfully!\n")
        else:
            print("Restock cancelled.\n")
    except ValueError:
        print("Please enter a valid number.\n")


def search_shoe():
    '''
    Search and display a shoe by its SKU code.
    '''
    print("\nSearch for a Shoe by Code")
    code = input("Please enter the shoe code (SKU): ").strip().lower()
    found = False

    for shoe in shoe_list:
        if shoe.code.lower() == code:
            print(f"Shoe Found:\n{shoe}\n")
            found = True
            break

    if not found:
        print("No shoe found with that code.\n")


def value_per_item():
    '''
    Display total value for each shoe (cost * quantity).
    '''
    print("\n💰 Value per Item")
    if not shoe_list:
        print("No shoes to display.\n")
        return

    print("{:<20} | {:<10} | {:<10} | {:>12}".format("Product", "Code", "Unit Cost", "Total Value"))
    print("-" * 60)
    for shoe in shoe_list:
        total_value = shoe.get_cost() * shoe.get_quantity()
        print(f"{shoe.product:<20} | {shoe.code:<10} | R{shoe.get_cost():<9.2f} | R{total_value:>10.2f}")
    print()


def highest_qty():
    '''
    Find and display the shoe with the highest quantity.
    '''
    print("\nHighest Stocked Shoe (FOR SALE!)")
    if not shoe_list:
        print("No data available.\n")
        return

    highest = max(shoe_list, key=lambda x: x.get_quantity())
    print(f"{highest.product} is available in large quantity! Promotion item!")
    print(highest, "\n")


def update_inventory_file():
    '''
    Overwrite inventory.txt with current contents of shoe_list.
    '''
    try:
        with open("inventory.txt", "w") as file:
            file.write("Country,Code,Product,Cost,Quantity\n")
            for shoe in shoe_list:
                file.write(f"{shoe.country},{shoe.code},{shoe.product},{shoe.cost},{shoe.quantity}\n")
    except Exception as e:
        print(f"Error writing to file: {e}")


#========== MAIN MENU ==========

def main():
    '''
    Displays a menu and calls appropriate functions based on user choice.
    '''
    read_shoes_data()  # This part shows load shoes from file

    while True:
        print("==========  SHOE INVENTORY MENU ==========")
        print("1. View all shoes")
        print("2. Add a new shoe")
        print("3. Restock lowest quantity shoe")
        print("4. Search for a shoe by code")
        print("5. Show value per item")
        print("6. Show highest quantity shoe (FOR SALE!)")
        print("7. Exit")

        choice = input("Please enter your choice (1–7): ").strip()

        if choice == "1":
            view_all()
        elif choice == "2":
            capture_shoes()
        elif choice == "3":
            re_stock()
        elif choice == "4":
            search_shoe()
        elif choice == "5":
            value_per_item()
        elif choice == "6":
            highest_qty()
        elif choice == "7":
            print("Exiting, Goodbye!... Have a great day!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 7.\n")


# Run program
if __name__ == "__main__":
    main()