# This shows the fixed code and the errors of the example program.

# The errors are written as comments next to the line where to code got fixed.

print("Welcome to the error program")  # Syntax error: Missing parentheses for print function in Python 3

print("\n")  # Syntax error: Indentation fixed and parentheses added for print

# Variables declaring the user's age, casting the str to an int, and printing the result
age_Str = "24"  # Syntax error: Used '==' instead of '=' for assignment; Also removed " years old" to allow int conversion

age = int(age_Str)  # Runtime error: fixed above so int() can convert properly

print("I'm " + str(age) + " years old.")  # Type error (runtime error): must convert age (int) to string for concatenation

# Variables declaring additional years and printing the total years of age
years_from_now = 3  # Logical error: originally a string, changed to int to allow arithmetic

total_years = age + years_from_now  # Logical error fixed by above change: adding int + int

print("The total number of years: " + str(total_years))  # Syntax error: used wrong variable name and missing parentheses for print; convert int to string

# Variable to calculate the total number of months from the given number of years and printing the result
total_months = total_years * 12  # Logical error: variable name corrected from 'total' to 'total_years' for calculation

print("In 3 years and 6 months, I'll be " + str(total_months + 6) + " months old")  # Logical error: added 6 months and converted to string, added parentheses to print