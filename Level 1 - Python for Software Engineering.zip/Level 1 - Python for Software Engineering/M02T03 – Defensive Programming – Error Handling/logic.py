import random

def guess_the_number():
    # This part shows where you generate a random secret number between 1 and 10
    secret_number = random.randint(1, 10)
    attempts = 0

    print("Guess the secret number between 1 and 10!")

    # This part shows where you allow the user up to 3 attempts
    while attempts < 3:
        guess = int(input("Your guess: "))
        attempts += 1

        if guess == secret_number:
            print("Congratulations! You guessed it!")
            break
        elif guess < secret_number:
            print("Too low!")
        else:
            print("Too high!")

    # This condition runs if user uses all 3 attempts without guessing correctly
    if attempts == 3:
        # The comments here shows the LOGICAL ERROR:
        # Here, the program prints 'guess', which is the last input by the user,
        # not the 'secret_number' that they were supposed to guess.
        # This can mislead the user because the actual secret number remains hidden.
        print(f"Sorry, you're out of attempts. The secret number was {guess}.")

if __name__ == "__main__":
    guess_the_number()