#--- Pseudocode of this task ---
#START

#DISPLAY "Please enter your name:"
#INPUT name
#DISPLAY name

#DISPLAY "Please enter your age:"
#INPUT age
#DISPLAY age

#DISPLAY "Hello, World!"

#END

# --- Python code of this task ---
# Prompt the user to enter their name
name = input("Please enter your name: ")
# Display the entered name
print(name)

# Prompt the user to enter their age
age = input("Please enter your age: ")
# Display the entered age
print(age)

# This part shows the Print "Hello, World!" on a new line
print("Hello, World!")