# This part shows where you Open the DOB.txt file in read mode
with open("C:\\Users\\jensi\\OneDrive\\Documents\\HyperionDev\\Task 12 IO Operations\\DOB.txt", "r") as file:

    # Read all lines from the file
    lines = file.readlines()

# Create empty lists to store names and birthdates
names = []
birthdates = []

# Loop through each line in the file
for line in lines:
    # Split the line into parts (assumes 3 parts for the birthdate)
    parts = line.strip().split()
    
    # Join the first two elements as the full name
    name = parts[0] + " " + parts[1]
    
    # Join the remaining elements as the birthdate
    birthdate = " ".join(parts[2:])
    
    # Append name and birthdate to respective lists
    names.append(name)
    birthdates.append(birthdate)

# Print the names
print("Name")
for name in names:
    print(name)

print()  # Blank line between sections

# Print the birthdates
print("Birthdate")
for date in birthdates:
    print(date)