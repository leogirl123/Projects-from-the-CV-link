# student_register.py

# This program allows the user to register student ID numbers
# for an exam venue and creates a text file for use as an attendance register.

def main():
    print("=== Exam Venue Student Registration ===\n")

    # Ask the user how many students are registering
    try:
        num_students = int(input("Enter the number of students to register: "))
        
        # Ensure the number is positive
        if num_students <= 0:
            print("The number of students must be greater than 0.")
            return
    except ValueError:
        print("Invalid input. Please enter a numeric value.")
        return

    # Open the file in write mode (overwrites if it already exists)
    with open("reg_form.txt", "w") as file:
        # Loop for the number of students specified
        for i in range(1, num_students + 1):
            while True:
                # Ask for the student ID
                student_id = input(f"Please enter Student ID for student {i}: ").strip()
                
                # Validate that input is not empty
                if student_id == "":
                    print("Student ID cannot be empty. Please try again.")
                else:
                    break

            # Write the student ID and dotted line to the file
            # This will serve as a signature line in the attendance register
            file.write(f"{student_id} .............................................\n")

    # Confirmation message
    print("\n=== Registration Complete ===")
    print(f"{num_students} students registered successfully.")
    print("The attendance register has been saved as 'reg_form.txt'.")
    
# Run the main function if this script is executed
if __name__ == "__main__":
    main()