def recursive_sum_upto_index(numbers, index):
    """
    Recursively sums elements of the list 'numbers' up to and including the element at 'index'.
    
    Parameters:
    numbers (list of int): The list of integers to sum.
    index (int): The index up to which to sum the elements (inclusive).
    
    Returns:
    int: The sum of elements from index 0 up to and including 'index'.
    
    Raises:
    IndexError: If 'index' is out of range for the list.
    """
    # Check if index is valid
    if index < 0 or index >= len(numbers):
        raise IndexError("Index is out of the valid range of the list.")
    
    # Base case: if index is 0, just return the element at index 0
    if index == 0:
        return numbers[0]
    
    # Recursive case: sum current element plus sum of previous elements up to index-1
    return numbers[index] + recursive_sum_upto_index(numbers, index - 1)


# Example usage:
if __name__ == "__main__":
    example_list = [1, 3, 5, 7, 9]
    idx = 3
    result = recursive_sum_upto_index(example_list, idx)
    print(f"Sum of elements up to index {idx} is: {result}")