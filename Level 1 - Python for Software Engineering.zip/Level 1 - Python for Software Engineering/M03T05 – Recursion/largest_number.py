def find_largest_recursive(nums):
    """
    Recursively finds the largest number in a list of integers.

    Args:
        nums (list): A list of integers.

    Returns:
        int: The largest integer in the list.

    Raises:
        ValueError: If the input list is empty.
    """

    # Check if the input list is empty
    if not nums:
        raise ValueError("The input list is empty.")

    # Base case:
    # If the list has only one element, return it as the largest number
    if len(nums) == 1:
        return nums[0]

    # Recursive case:
    # Find the largest number in the rest of the list
    largest_of_rest = find_largest_recursive(nums[1:])

    # Compare the first element with the largest of the rest
    if nums[0] > largest_of_rest:
        return nums[0]
    else:
        return largest_of_rest


# Example usage:
numbers = [3, 5, 2, 9, 1]
largest_number = find_largest_recursive(numbers)

print(f"The largest number in the list {numbers} is: {largest_number}")