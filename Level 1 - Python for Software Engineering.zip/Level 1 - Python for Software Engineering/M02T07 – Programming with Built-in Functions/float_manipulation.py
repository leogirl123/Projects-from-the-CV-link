import statistics

# This part shows where you get 10 float inputs from the user and store in a list
numbers = []
print("Please enter 10 numbers (can be whole numbers or decimals):")
for i in range(10):
    num = float(input(f"Enter number {i+1}: "))
    numbers.append(num)

# This part shows where you find the total of all numbers
total = sum(numbers)
print(f"\nTotal of the numbers: {total}")

# This part shows where you find the index of the maximum number
max_index = numbers.index(max(numbers))
print(f"Index of the maximum number: {max_index}")

# This part shows where you find the index of the minimum number
min_index = numbers.index(min(numbers))
print(f"Index of the minimum number: {min_index}")

# This part shows where you calculate the average (mean), rounded to 2 decimal places
average = round(statistics.mean(numbers), 2)
print(f"Average (mean) of the numbers: {average}")

# This part shows where you find the median
median = statistics.median(numbers)
print(f"Median of the numbers: {median}")