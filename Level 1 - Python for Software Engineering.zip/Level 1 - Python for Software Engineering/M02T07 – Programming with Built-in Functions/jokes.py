import random

# This part shows List of jokes, each joke is a dictionary with 'setup' and 'punchline'
jokes = [
    {"setup": "How did the ocean say hi?", "punchline": "It waves!"},
    {"setup": "Why did the bicycle fall over?", "punchline": "Because it was two-tired!"},
    {"setup": "Why did the math book look sad?", "punchline": "Because it had too many problems."},
    {"setup": "Why don’t skeletons fight each other?", "punchline": "They don’t have the guts!"},
    {"setup": "What do you call a pile of cats?", "punchline": "A meowtain!"},
    {"setup": "What do you call cheese that isn't yours?", "punchline": "Nacho cheese."},
    {"setup": "Why can't your nose be 12 inches long?", "punchline": "Because then it would be a foot."}
]

# This part shows where you pick a random joke
joke = random.choice(jokes)

# This part shows where you print the joke
print("Check out this joke for you!")
print(joke['setup'])
print(joke['punchline'])