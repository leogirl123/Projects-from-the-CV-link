# Declare initial variables here
num1 = 99.23
num2 = 23
num3 = 150
string1 = "100"

# Convert all the variables
num1 = int(num1)
num2 = float(num2)
num3 = str(num3)
string1 = int(string1)

# Print each variable on a separate line
print(num1)
print(num2)
print(num3)
print(string1)