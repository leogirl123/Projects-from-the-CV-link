# Collect the user details using input()
name = input("Please enter your full name: ")
age = input("Please enter your age: ")
house_number = input("Please enter your house number: ")
street_name = input("Please enter your street name: ")

# Print all the details of the sentence
print(f"This is {name}. He/she is {age} years old and lives at house number {house_number} on {street_name}.")