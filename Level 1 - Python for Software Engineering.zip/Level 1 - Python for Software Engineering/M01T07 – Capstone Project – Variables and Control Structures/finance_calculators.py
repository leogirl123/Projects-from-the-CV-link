import math

# This part shows where you display the initial menu to the user
menu = """
Investment - to calculate the amount of interest you'll earn on your investment.
Bond       - to calculate the amount you'll have to pay on a home loan.

Enter either 'investment' or 'bond' from the menu above to proceed:
"""
choice = input(menu).strip().lower()

# This part shows where you handle INVESTMENT option
if choice == "investment":
    try:
        # This part shows where you get user input for investment calculation
        deposit = float(input("Please enter the amount you are depositing (e.g., 1000): "))
        rate = float(input("Please enter the interest rate (only the number, e.g., 8): "))
        years = int(input("Please enter the number of years you plan to invest: "))
        interest_type = input("Please enter the interest type ('simple' or 'compound'): ").strip().lower()
        
        # This part shows where you convert interest rate to a decimal
        r = rate / 100
        
        # This part shows where you calculate and display based on interest type
        if interest_type == "simple":
            total = deposit * (1 + r * years)
            print(f"\nWith simple interest, you'll get back: R{total:.2f}")
        elif interest_type == "compound":
            total = deposit * math.pow((1 + r), years)
            print(f"\nWith compound interest, you'll get back: R{total:.2f}")
        else:
            print("Invalid interest type. Please enter either 'simple' or 'compound'.")
    except ValueError:
        print("Invalid input. Please make sure you enter numbers where expected.")

# This part shows where you handle BOND option
elif choice == "bond":
    try:
        # This part shows where you get user input for bond repayment calculation
        present_value = float(input("Enter the present value of the house: "))
        rate = float(input("Enter the annual interest rate (only the number, e.g., 7): "))
        months = int(input("Enter the number of months to repay the bond: "))

        # This part shows where you convert annual rate to monthly interest rate
        i = (rate / 100) / 12

        # This part shows where you calculate repayment using the bond formula
        repayment = (i * present_value) / (1 - math.pow((1 + i), -months))
        print(f"\nYour monthly bond repayment will be: R{repayment:.2f}")
    except ValueError:
        print("Invalid input. Please make sure you enter numbers where expected.")

# This part shows where you handle invalid menu option
else:
    print("Invalid selection. Please type 'investment' or 'bond'.")
