# This part shows the program to collect valid numbers from the user and calculate their average
print("Hello! This program will help you calculate the average of numbers you enter.")
print("Please kindly enter numbers one at a time. Enter -1 when you are finished.")
print("Note: 0 is not considered a valid input and will be ignored.\n")

# Initialize an empty list to store valid numbers
valid_numbers = []

while True:
    try:
        # Prompt the user for input
        user_input = input("Please kindly enter a number (-1 to finish): ")
        number = int(user_input)

        # Check for the exit condition
        if number == -1:
            print("Thank you! Calculating the average of valid numbers entered...\n")
            break
        elif number == 0:
            print("0 is not a valid input and will be skipped. Please try again.")
            continue
        else:
            valid_numbers.append(number)
    except ValueError:
        print("That doesn't seem to be a valid number. Please enter an integer.")

# Calculate and display the average
if valid_numbers:
    average = sum(valid_numbers) / len(valid_numbers)
    print(f"The average of the valid numbers you entered is: {average:.2f}")
else:
    print("No valid numbers were entered to calculate an average.")