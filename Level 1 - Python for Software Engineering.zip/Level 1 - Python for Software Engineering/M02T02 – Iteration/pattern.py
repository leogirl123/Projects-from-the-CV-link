n = 5  # This part shows the maximum stars

for i in range(1, n + 4):  # 1 to 8 inclusive
    if i <= n:
        print('*' * i)
    else:
        print('*' * (2*n - i))