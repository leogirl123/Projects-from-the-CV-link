def is_valid_position(row, col, rows, cols):
    """
    Check if the (row, col) position is inside the grid boundaries.
    Returns True if valid, False otherwise.
    """
    return 0 <= row < rows and 0 <= col < cols

def count_adjacent_mines(grid, row, col):
    """
    Count how many mines ('#') are adjacent to the cell at (row, col).
    Adjacent means all 8 surrounding cells: horizontal, vertical, diagonal.
    """
    # Directions representing all 8 neighbors:
    directions = [
        (-1, -1), (-1, 0), (-1, 1),  # NW, N, NE
        (0, -1),           (0, 1),    # W,      E
        (1, -1),  (1, 0),  (1, 1)     # SW, S,  SE
    ]
    
    count = 0  # Number of adjacent mines found
    rows = len(grid)
    cols = len(grid[0])

    # Check each direction for mines
    for dr, dc in directions:
        nr, nc = row + dr, col + dc  # Calculate neighbor's coordinates
        
        # Check if neighbor is within bounds and is a mine
        if is_valid_position(nr, nc, rows, cols) and grid[nr][nc] == '#':
            count += 1
            
    return count

def mine_sweeper(input_grid):
    """
    Given an input grid of strings with '-' and '#',
    return a new grid where each '-' is replaced by the number
    of adjacent mines, and '#' remains unchanged.
    """
    # Convert each row from string to list of characters for mutability
    grid = [list(row) for row in input_grid]
    rows = len(grid)
    cols = len(grid[0])

    # Iterate over every cell in the grid
    for row in range(rows):
        for col in range(cols):
            # Only process cells that are mine-free ('-')
            if grid[row][col] == '-':
                # Count adjacent mines and replace '-'
                mines = count_adjacent_mines(grid, row, col)
                grid[row][col] = str(mines)

    # Convert each row back to a string before returning
    return [''.join(row) for row in grid]

# Example usage:
input_grid = [
    "--#",
    "-#-",
    "--#"
]

output_grid = mine_sweeper(input_grid)

# Print the output grid line by line
for line in output_grid:
    print(line)
