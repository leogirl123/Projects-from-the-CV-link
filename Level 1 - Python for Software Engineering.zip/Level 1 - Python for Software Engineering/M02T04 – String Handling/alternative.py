def alternate_char_case(s):
    """
    Converts alternate characters in the string to uppercase and lowercase.
    Even index chars uppercase, odd index chars lowercase.
    """
    result_chars = []
    for i, char in enumerate(s):
        if char.isalpha():  # Only change case for alphabets
            if i % 2 == 0:
                result_chars.append(char.upper())
            else:
                result_chars.append(char.lower())
        else:
            # Keep non-alphabet characters as they are
            result_chars.append(char)
    return ''.join(result_chars)


def alternate_word_case(s):
    """
    Converts alternate words in the string to lowercase and uppercase.
    Even index words lowercase, odd index words uppercase.
    """
    words = s.split()
    for i in range(len(words)):
        if i % 2 == 0:
            words[i] = words[i].lower()
        else:
            words[i] = words[i].upper()
    return ' '.join(words)


def main():
    user_string = input("Enter a string: ")

    # Task 1: Alternate characters case
    alt_char_string = alternate_char_case(user_string)
    print("\nAlternate characters uppercase/lowercase:")
    print(alt_char_string)

    # Task 2: Alternate words case
    alt_word_string = alternate_word_case(user_string)
    print("\nAlternate words uppercase/lowercase:")
    print(alt_word_string)


if __name__ == "__main__":
    main()