# This part shows where you get the user input
age_input = input("Please enter your age: ")

# This part shows where you convert input to integer, also displays the appropriate message according to the ages
try:
    age = int(age_input)

    if age > 100:
        print("Sorry, you're dead.")
    elif age == 21:
        print("Congrats on your 21st!")
    elif age >= 65:
        print("Enjoy your retirement!")
    elif age >= 40:
        print("You're over the hill.")
    elif age < 13:
        print("You qualify for the kiddie discount.")
    else:
        print("Age is but a number.")
except ValueError:
    print("Invalid input. Please kindly enter a valid whole number (integer).")

