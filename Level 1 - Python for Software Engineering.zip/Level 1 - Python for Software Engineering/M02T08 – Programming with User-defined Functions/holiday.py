# This part shows the function to calculate hotel cost
def hotel_cost(num_nights):
    price_per_night = 100
    return num_nights * price_per_night

# This part shows the function to calculate plane cost based on city using if/elif/else
def plane_cost(city_flight):
    city_flight = city_flight.lower()
    if city_flight == "london":
        return 250
    elif city_flight == "new york":
        return 500
    elif city_flight == "paris":
        return 200
    elif city_flight == "chennai":
        return 300
    else:
        return None  # Invalid city

# This part shows the function to calculate car rental cost
def car_rental(rental_days):
    daily_rental_rate = 50
    return rental_days * daily_rental_rate

# This part shows the function to calculate total holiday cost
def holiday_cost(num_nights, city_flight, rental_days):
    total = hotel_cost(num_nights) + plane_cost(city_flight) + car_rental(rental_days)
    return total

# Start of the main program
print("Welcome to the Holiday Cost Calculator!")
print("Please choose a city from the following options: London, New York, Paris, Chennai")

# Get and validate city input (loop until valid)
while True:
    city_flight = input("Please enter the city you'll be flying to: ").strip().lower()
    if plane_cost(city_flight) is not None:
        break
    print("Invalid city entered. Please choose from London, New York, Paris, or Chennai.\n")

# Get and validate number of nights (loop until valid)
while True:
    try:
        num_nights = int(input("Please enter the number of nights you'll be staying in a hotel: "))
        if num_nights >= 0:
            break
        else:
            print("Please enter a non-negative number.\n")
    except ValueError:
        print("Please enter a valid whole number for nights.\n")

# Get and validate rental days (loop until valid)
while True:
    try:
        rental_days = int(input("Please enter the number of days you'll be renting a car: "))
        if rental_days >= 0:
            break
        else:
            print("Please enter a non-negative number.\n")
    except ValueError:
        print("Please enter a valid whole number for rental days.\n")

# Calculate costs
hotel = hotel_cost(num_nights)
flight = plane_cost(city_flight)
car = car_rental(rental_days)
total = holiday_cost(num_nights, city_flight, rental_days)

# Display summary
print("\n----- Here is the Holiday Cost Summary! -----")
print(f"Destination City: {city_flight.title()}")
print(f"Hotel for {num_nights} nights: £{hotel:.2f}")
print(f"Flight to {city_flight.title()}: £{flight:.2f}")
print(f"Car rental for {rental_days} days: £{car:.2f}")
print(f"Total Holiday Cost: £{total:.2f}")