# This shows the function to print dictionary values given the keys
def print_values_of(dictionary, keys):
    for key in keys:
        # FIX 1: Changed 'dictionary[k]' to 'dictionary[key]' to use the correct variable name
        print(dictionary[key])

# This shows the dictionary of Simpsons catch phrases
simpson_catch_phrases = {
    "lisa": "BAAAAAART!", 
    "bart": "Eat My Shorts!", 
    "marge": "Mmm~mmmmm", 
    "homer": "d'oh!",  # FIX 2: Changed outer quotes from single to double to avoid conflict with apostrophe in "d'oh!"
    "maggie": "(Pacifier Suck)"
}

# FIX 3: Changed function call to pass the second argument as a list of keys
print_values_of(simpson_catch_phrases, ['lisa', 'bart', 'homer'])

'''
Expected console output:

BAAAAAART!
Eat My Shorts!
d'oh!
'''
