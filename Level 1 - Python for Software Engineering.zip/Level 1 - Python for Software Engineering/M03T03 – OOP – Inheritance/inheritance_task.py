# This part define the base class Course
class Course:
    # Class attribute for the course name
    name = "Fundamentals of Computer Science"

    # Class attribute for the contact website
    contact_website = "www.hyperiondev.com"

    # Method to display contact details
    def contact_details(self):
        print("Please contact us by visiting", self.contact_website)

    # Method to display head office location
    def head_office(self):
        print("Head Office Location: Cape Town")


# Define the subclass OOPCourse, which inherits from Course
class OOPCourse(Course):
    # Constructor to initialize description and trainer attributes
    def __init__(self, description="OOP Fundamentals", trainer="Mr Anon A. Mouse"):
        self.description = description
        self.trainer = trainer

    # Method to display trainer details and course description
    def trainer_details(self):
        print("Course Description:", self.description)
        print("Trainer Name:", self.trainer)

    # Method to display the course ID
    def show_course_id(self):
        print("Course ID: #12345")


# Create an object of the OOPCourse subclass
course_1 = OOPCourse()

# Call methods to display information
course_1.contact_details()     # Inherited from Course
course_1.trainer_details()     # Defined in OOPCourse
course_1.show_course_id()      # Defined in OOPCourse