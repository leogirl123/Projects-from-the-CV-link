# This part define the Adult class
class Adult:
    def __init__(self, name, age, hair_color, eye_color):
        self.name = name
        self.age = age
        self.hair_color = hair_color
        self.eye_color = eye_color

    def can_drive(self):
        print(f"{self.name} is old enough to drive.")


# Define the Child class as a subclass of Adult
class Child(Adult):
    def can_drive(self):
        print(f"{self.name} is too young to drive.")


# --- Main program starts here ---

# Get user's name, hair color, and eye color
name = input("Please enter your name: ")
hair_color = input("Please enter your hair color: ")
eye_color = input("Please enter your eye color: ")

# Keep asking for age until a valid number is entered
while True:
    age_input = input("Please enter your age: ")
    try:
        age = int(age_input)
        break  # Exit the loop if input is valid
    except ValueError:
        print("Invalid input for age. Please enter a number.")

# Determine whether the person is an adult or a child
if age >= 18:
    person = Adult(name, age, hair_color, eye_color)
else:
    person = Child(name, age, hair_color, eye_color)

# Call the can_drive method to check driving eligibility
person.can_drive()