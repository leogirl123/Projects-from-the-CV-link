# This part shows where you create a list of menu items
menu = ['coffee', 'tea', 'biscuits', 'cake']

# This part shows where you create a dictionary for stock of each item
stock = {
    'coffee': 25,
    'tea': 20,
    'biscuits': 15,
    'cake': 10
}

# Create a dictionary for prices of each item
price = {
    'coffee': 4.0,
    'tea': 3.5,
    'biscuits': 6.0,
    'cake': 3.0
}

# Calculate the total worth of stock
total_stock = 0
for item in menu:
    item_value = stock[item] * price[item]
    total_stock += item_value

# Print the result
print(f"The total worth of the stock in the café is: £{total_stock:.2f}")