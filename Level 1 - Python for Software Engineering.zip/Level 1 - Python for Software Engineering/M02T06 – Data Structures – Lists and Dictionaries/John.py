# This part shows where you initialize an empty list to store names that are not "John"
incorrect_names = []

# This part shows where you start an infinite loop to repeatedly prompt the user for input
while True:
    # This part shows where you prompt the user to enter their name and remove any leading/trailing spaces
    name = input("Enter your name: ").strip()
    
    # Check if the entered name, converted to lowercase, is "john"
    if name.lower() == "john":
        # If the name is "john", exit the loop
        break
    
    # If the name is not "john", add it to the list of incorrect names
    incorrect_names.append(name)

# This part shows where after the loop ends (user entered "john"), print the list of incorrect names
print("Incorrect names:", incorrect_names)