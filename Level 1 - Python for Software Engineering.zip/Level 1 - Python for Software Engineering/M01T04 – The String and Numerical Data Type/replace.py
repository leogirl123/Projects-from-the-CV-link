# This part will save this sentence as a single string
sentence = "The!quick!brown!fox!jumps!over!the!lazy!dog"

# This part replaces every "!" with a blank space and prints the result
sentence_with_spaces = sentence.replace("!", " ")
print(sentence_with_spaces)  

# This part prints the sentence in uppercase
uppercase_sentence = sentence_with_spaces.upper()
print(uppercase_sentence)  

# This part shows when you print the sentence in reverse
reversed_sentence = sentence_with_spaces[::-1]
print(reversed_sentence)  