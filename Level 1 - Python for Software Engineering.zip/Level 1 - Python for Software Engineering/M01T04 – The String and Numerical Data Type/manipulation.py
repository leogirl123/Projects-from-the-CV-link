# This part shows the part where it asks the user to enter a sentence
str_manip = input("Please enter a sentence: ")

# Calculate and display the length of str_manip
length = len(str_manip)
print("Length of the sentence:", length)

# This shows finding the last letter in str_manip
last_letter = str_manip[-1]
print("Last letter in the sentence:", last_letter)

# Replace every occurrence of this letter in str_manip with '@'
replaced_str = str_manip.replace(last_letter, '@')
print("Sentence after replacing last letter with '@':", replaced_str)

# Print the last 3 characters in str_manip backwards
last_three_reversed = str_manip[-3:][::-1]
print("Last three characters reversed:", last_three_reversed)

# Create a five-letter word made up of the first three and last two characters in str_manip
# Handle the case where str_manip is shorter than 5 characters
if length >= 5:
    five_letter_word = str_manip[:3] + str_manip[-2:]
else:
    # combine what is available when the sentence is too short
    five_letter_word = str_manip

print("Five-letter word:", five_letter_word)