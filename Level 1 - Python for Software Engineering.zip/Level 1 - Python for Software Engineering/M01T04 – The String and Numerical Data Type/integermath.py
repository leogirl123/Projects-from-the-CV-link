# prompt the user for three different integers
print("Hello! Let's do some calculations.")
print("Please enter three different integers when prompted.\n")

num1 = int(input("Please enter the first integer: "))
num2 = int(input("Please enter the second integer: "))
num3 = int(input("Please enter the third integer: "))

# The calculations are performed here
sum_all = num1 + num2 + num3
difference = num1 - num2
product = num3 * num1

# Avoid division by zero
if num3 != 0:
    division = sum_all / num3
else:
    division = "Undefined (cannot divide by zero)"

# Display the results
print("\nThank you! Here are the results:")
print(f"1. Sum of all three numbers: {sum_all}")
print(f"2. First number minus the second: {difference}")
print(f"3. Third number multiplied by the first: {product}")
print(f"4. Sum of all three divided by the third: {division}")