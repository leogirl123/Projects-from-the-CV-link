# This part shows where you create the list of friends' full names
friends_names = ["Amelia Smith", "Johanna Moore", "Jack Peterson"]

# This part shows where you print the first friend's name
print("First friend:", friends_names[0])

# This part shows where you print the last friend's name
print("Last friend:", friends_names[-1])

# This part shows where you print the total number of friends
print("Total number of friends:", len(friends_names))

# This part shows where you create a corresponding list of friends' ages
friends_ages = [25, 28, 23]

# This part shows where you print each friend's name and age in a formatted sentence
for name, age in zip(friends_names, friends_ages):
    print(f"{name} is {age} years old.")