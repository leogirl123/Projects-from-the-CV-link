# Define the Album class
class Album:
    def __init__(self, album_name, album_artist, number_of_songs):
        # Initialize the instance variables
        self.album_name = album_name
        self.album_artist = album_artist
        self.number_of_songs = number_of_songs

    def __str__(self):
        # Return a string representation of the Album object
        return f"({self.album_name}, {self.album_artist}, {self.number_of_songs})"

# Step 3: Create a list called albums1 and add five Album objects
albums1 = [
    Album("Abbey Road", "The Beatles", 17),
    Album("Thriller", "Michael Jackson", 9),
    Album("Back in Black", "AC/DC", 10),
    Album("Rumours", "Fleetwood Mac", 11),
    Album("Hotel California", "Eagles", 9)
]

# Print the albums1 list
print("Albums1 List:")
for album in albums1:
    print(album)

# Step 4: Sort albums1 by number_of_songs
albums1.sort(key=lambda album: album.number_of_songs)
print("\nAlbums1 Sorted by number_of_songs:")
for album in albums1:
    print(album)

# Step 5: Swap the element at position 0 with the element at position 1
albums1[0], albums1[1] = albums1[1], albums1[0]
print("\nAlbums1 After Swapping First Two Elements:")
for album in albums1:
    print(album)

# Step 6: Create a new list called albums2
albums2 = []

# Step 7: Add five Album objects to albums2
albums2.extend([
    Album("1989", "Taylor Swift", 13),
    Album("Goodbye Yellow Brick Road", "Elton John", 17),
    Album("Born in the U.S.A.", "Bruce Springsteen", 12),
    Album("The Wall", "Pink Floyd", 26),
    Album("25", "Adele", 11)
])
print("\nAlbums2 List:")
for album in albums2:
    print(album)

# Step 8: Copy all albums from albums1 to albums2
albums2.extend(albums1)

# Step 9: Add two more albums to albums2
albums2.append(Album("Dark Side of the Moon", "Pink Floyd", 9))
albums2.append(Album("Oops! . I Did It Again", "Britney Spears", 16))

# Step 10: Sort albums2 alphabetically by album_name
albums2.sort(key=lambda album: album.album_name)
print("\nAlbums2 Sorted Alphabetically by Album Name:")
for album in albums2:
    print(album)

# Step 11: Search for "Dark Side of the Moon" in albums2 and print index
search_name = "Dark Side of the Moon"
index = -1
for i, album in enumerate(albums2):
    if album.album_name == search_name:
        index = i
        break

print(f"\nIndex of '{search_name}' in albums2: {index}")