# sort_and_search.py

# Initial unsorted list
numbers = [27, -3, 4, 5, 35, 2, 1, -40, 7, 18, 9, -1, 16, 100]

# Step 1: Linear Search on the unsorted list
def linear_search(lst, target):
    """Performs a linear search for the target in the list."""
    for i, value in enumerate(lst):
        if value == target:
            return i
    return -1

# Search for the number 9 using Linear Search
target = 9
index = linear_search(numbers, target)
print(f"Step 1: Linear Search - Number {target} found at index {index}" if index != -1 else "Number not found.")

# Why linear search?
# Linear search is a good choice here because the list is unsorted.
# It doesn't require any sorting and can find the item in a single pass.

# Step 2: Sort the list using Insertion Sort
def insertion_sort(lst):
    """Sorts a list in ascending order using insertion sort algorithm."""
    for i in range(1, len(lst)):
        key = lst[i]
        j = i - 1
        # Move elements that are greater than key to one position ahead
        while j >= 0 and lst[j] > key:
            lst[j + 1] = lst[j]
            j -= 1
        lst[j + 1] = key
    return lst

# Sort the numbers
sorted_numbers = insertion_sort(numbers.copy())
print("Step 2: Sorted list using Insertion Sort:")
print(sorted_numbers)

# Step 3: Use Binary Search on the sorted list
def binary_search(lst, target):
    """Performs binary search on a sorted list."""
    left, right = 0, len(lst) - 1
    while left <= right:
        mid = (left + right) // 2
        if lst[mid] == target:
            return mid
        elif lst[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1

# Search for number 9 in the sorted list
index_sorted = binary_search(sorted_numbers, target)
print(f"Step 3: Binary Search - Number {target} found at index {index_sorted}" if index_sorted != -1 else "Number not found.")

# Why binary search?
# Binary search is efficient for sorted lists (O(log n) time complexity).
# It's great for large datasets where performance matters.

# Real-world use case:
# Binary search is widely used in database indexing, looking up dictionary words,
# auto-complete suggestions, or finding records in sorted logs.