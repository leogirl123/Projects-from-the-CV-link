def merge_sort_by_length_desc(arr):
    """
    Modified merge sort algorithm to sort strings by their length in descending order.
    """
    if len(arr) > 1:
        mid = len(arr) // 2  # Find the middle of the list
        left_half = arr[:mid]  # Split the list into left and right halves
        right_half = arr[mid:]

        # Recursively sort both halves
        merge_sort_by_length_desc(left_half)
        merge_sort_by_length_desc(right_half)

        # Merge the sorted halves
        i = j = k = 0

        # Compare lengths and sort in descending order
        while i < len(left_half) and j < len(right_half):
            if len(left_half[i]) >= len(right_half[j]):
                arr[k] = left_half[i]
                i += 1
            else:
                arr[k] = right_half[j]
                j += 1
            k += 1

        # Copy any remaining elements of left_half
        while i < len(left_half):
            arr[k] = left_half[i]
            i += 1
            k += 1

        # Copy any remaining elements of right_half
        while j < len(right_half):
            arr[k] = right_half[j]
            j += 1
            k += 1

# === Test Lists ===
list1 = ["banana", "apple", "kiwi", "pineapple", "mango", "grapefruit", "blueberry", "pear", "plum", "fig"]
list2 = ["chocolate", "icecream", "cake", "donut", "marshmallow", "brownie", "eclair", "cookie", "tart", "mousse"]
list3 = ["elephant", "cat", "hippopotamus", "dog", "tiger", "giraffe", "bear", "leopard", "monkey", "wolf"]

# === Run and Display Results ===
for idx, test_list in enumerate([list1, list2, list3], start=1):
    print(f"\nOriginal List {idx}:")
    print(test_list)

    merge_sort_by_length_desc(test_list)

    print(f"Sorted by Length Descending List {idx}:")
    print(test_list)