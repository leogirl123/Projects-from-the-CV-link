import os

def perform_calculation():
    """Performs a calculation based on user input and saves it to equations.txt"""
    try:
        # This part shows where you get first number from the user
        num1 = float(input("Please enter the first number: "))
        
        # Get the operator
        operator = input("Please enter an operation (+, -, *, /): ").strip()
        if operator not in ['+', '-', '*', '/']:
            print("Invalid operator. Please use one of +, -, *, /.")
            return
        
        # Get second number
        num2 = float(input("Please enter the second number: "))

        # Perform calculation with error handling
        if operator == '+':
            result = num1 + num2
        elif operator == '-':
            result = num1 - num2
        elif operator == '*':
            result = num1 * num2
        elif operator == '/':
            if num2 == 0:
                print("Error: Cannot divide by zero.")
                return
            result = num1 / num2

        # Create the equation string
        equation = f"{num1} {operator} {num2} = {result}"
        print("Result:", result)

        # Save to file
        with open("equations.txt", "a") as file:
            file.write(equation + "\n")

    except ValueError:
        print("Invalid input. Please enter numeric values.")

def print_previous_equations():
    """Reads and displays previous calculations from equations.txt"""
    try:
        if not os.path.exists("equations.txt"):
            print("No previous equations found.")
            return

        with open("equations.txt", "r") as file:
            lines = file.readlines()
            if not lines:
                print("No previous equations found.")
            else:
                print("\nPrevious Equations:")
                for line in lines:
                    print(line.strip())
    except Exception as e:
        print("An error occurred while reading the file:", e)

def main():
    """Main function to run the calculator application"""
    print("Welcome to the Simple Calculator App")

    while True:
        print("\nChoose an option:")
        print("1. Perform a calculation")
        print("2. View previous calculations")
        print("3. Exit")

        choice = input("Please enter your choice (1/2/3): ").strip()

        if choice == '1':
            perform_calculation()
        elif choice == '2':
            print_previous_equations()
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()