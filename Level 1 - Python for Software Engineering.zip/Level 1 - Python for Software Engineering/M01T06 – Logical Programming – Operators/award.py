def determine_award(total_time):
    if 0 <= total_time <= 100:
        return "Provincial colours"
    elif 101 <= total_time <= 105:
        return "Provincial half colours"
    elif 106 <= total_time <= 110:
        return "Provincial scroll"
    else:
        return "No award"

def main():
    print("Enter the time taken (in minutes) for each triathlon event:")

    try:
        swim_time = int(input("Swimming time: "))
        cycle_time = int(input("Cycling time: "))
        run_time = int(input("Running time: "))
    except ValueError:
        print("Please kindly enter valid integer values for time.")
        return

    total_time = swim_time + cycle_time + run_time
    print(f"\nTotal time taken for the triathlon: {total_time} minutes")

    award = determine_award(total_time)
    print(f"Award: {award}")

# This part shows where you run the program
if __name__ == "__main__":
    main()